
import Link from 'next/link';
import Head from 'next/head';
import { ReactNode } from 'react';

export default function Layout({ title, children }: { title?: string; children: ReactNode }) {
  const t = title ? `${title} · Songsmith` : 'Songsmith';
  return (
    <>
      <Head>
        <title>{t}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Turn your lyrics into a custom song. Fast, honest, human-crafted." />
      </Head>
      <header className="border-b border-white/10">
        <nav className="container-nice flex items-center justify-between py-4">
          <Link href="/" className="font-bold text-lg">Songsmith</Link>
          <div className="flex items-center gap-3">
            <Link className="btn-secondary" href="/create">Make a Song</Link>
            <Link className="btn-secondary" href="/pricing">Pricing</Link>
          </div>
        </nav>
      </header>
      <main className="container-nice py-10">{children}</main>
      <footer className="border-t border-white/10 mt-16">
        <div className="container-nice py-8 text-sm text-white/60 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <p>© {new Date().getFullYear()} Songsmith. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/terms">Terms</Link>
            <Link href="/privacy">Privacy</Link>
            <a href="mailto:hello@example.com">Contact</a>
          </div>
        </div>
      </footer>
    </>
  );
}
