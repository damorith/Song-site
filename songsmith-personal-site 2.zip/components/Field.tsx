
type Props = {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  help?: string;
};
export default function Field({ label, htmlFor, help, children }: Props) {
  return (
    <div className="space-y-1">
      <label htmlFor={htmlFor} className="label">{label}</label>
      {children}
      {help && <p className="text-xs text-white/50">{help}</p>}
    </div>
  );
}
