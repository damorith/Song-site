
import Layout from '../components/Layout'

export default function Pricing(){
  const tiers = [
    {name:'Demo', price: '$99', features:['Simple arrangement','1 verse + chorus','MP3 delivery','1 revision']},
    {name:'Studio', price:'$349', features:['Full arrangement','2-3 minutes','WAV + MP3','2 revisions','Light mastering']},
    {name:'Pro', price:'$799', features:['Radio-ready production','3-4 minutes','WAV + MP3 + stems','Up to 3 revisions','Full mastering']},
  ]
  return (
    <Layout title="Pricing">
      <h1 className="text-3xl font-bold mb-6">Transparent Pricing</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {tiers.map((t)=>(
          <div key={t.name} className="card p-6 flex flex-col">
            <h3 className="text-xl font-semibold">{t.name}</h3>
            <div className="text-4xl font-extrabold mt-2">{t.price}</div>
            <ul className="mt-4 space-y-2 text-white/80 flex-1">
              {t.features.map((f,i)=>(<li key={i}>• {f}</li>))}
            </ul>
            <a href="/create" className="btn-primary mt-4 text-center">Start</a>
          </div>
        ))}
      </div>
    </Layout>
  )
}
