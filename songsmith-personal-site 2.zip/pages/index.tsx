
import Link from 'next/link'
import Layout from '../components/Layout'

export default function Home() {
  return (
    <Layout>
      <section className="py-16 text-center">
        <h1 className="text-4xl sm:text-6xl font-extrabold gradient-heading">Turn your lyrics into a song</h1>
        <p className="mt-6 text-white/70 max-w-2xl mx-auto">
          No gimmicks, no upsells. Share your words and vision; receive a custom song with transparent pricing and clear timelines.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Link className="btn-primary" href="/create">Start your song</Link>
          <Link className="btn-secondary" href="/pricing">See pricing</Link>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-6 mt-10">
        {[
          {title: 'Honest', text: 'Straightforward scope, timelines, and deliverables. No dark patterns.'},
          {title: 'Human', text: 'Real musicians craft, arrange, and produce. AI optional as a tool, never a crutch.'},
          {title: 'Yours', text: 'Clear ownership: you keep full usage rights to the final track.'},
        ].map((c,i)=>(
          <div key={i} className="card p-6">
            <h3 className="font-semibold text-lg">{c.title}</h3>
            <p className="text-white/70 mt-2">{c.text}</p>
          </div>
        ))}
      </section>

      <section className="mt-16 card p-6">
        <h2 className="text-2xl font-bold">How it works</h2>
        <ol className="mt-4 space-y-4 text-white/80">
          <li><b>1.</b> Submit your lyrics and vibe on the <Link className="underline" href="/create">Make a Song</Link> page.</li>
          <li><b>2.</b> We confirm scope and send an invoice. You’ll get a draft within the agreed window.</li>
          <li><b>3.</b> Up to two rounds of revisions. Delivery includes WAV, MP3, stems (optional), and lyric sheet.</li>
        </ol>
      </section>
    </Layout>
  )
}
