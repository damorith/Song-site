
import Layout from '../components/Layout'

export default function Terms(){
  return (
    <Layout title="Terms">
      <h1 className="text-3xl font-bold mb-4">Terms</h1>
      <div className="prose prose-invert max-w-none">
        <ul className="list-disc pl-6 space-y-2">
          <li>50% due at kickoff, balance on delivery. Refunds case-by-case before recording begins.</li>
          <li>You retain full usage rights to the final deliverables.</li>
          <li>We may request permission to showcase short excerpts in our portfolio; you can opt out.</li>
        </ul>
      </div>
    </Layout>
  )
}
