
import Layout from '../components/Layout'

export default function Privacy(){
  return (
    <Layout title="Privacy">
      <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
      <div className="prose prose-invert max-w-none">
        <p>We collect only what’s needed to make your song: your contact info and creative brief. We do not sell your data. Files are kept for delivery and support, then archived securely.</p>
      </div>
    </Layout>
  )
}
