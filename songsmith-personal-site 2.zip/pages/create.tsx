
import { useState } from 'react'
import Layout from '../components/Layout'
import Field from '../components/Field'

export default function Create() {
  const [status, setStatus] = useState<'idle'|'submitting'|'done'|'error'>('idle')

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setStatus('submitting')
    const form = e.currentTarget
    const data = new FormData(form)
    const payload = Object.fromEntries(data.entries())

    try {
      const res = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      if (!res.ok) throw new Error('Request failed')
      setStatus('done')
      form.reset()
    } catch (err) {
      console.error(err)
      setStatus('error')
    }
  }

  return (
    <Layout title="Make a Song">
      <div className="max-w-3xl mx-auto card p-6">
        <h1 className="text-2xl font-bold mb-6">Tell us about your song</h1>
        <form onSubmit={handleSubmit} className="space-y-5" noValidate>
          <Field label="Your Name" htmlFor="name">
            <input className="input" id="name" name="name" required placeholder="Jane Doe" />
          </Field>
          <Field label="Email (for delivery)" htmlFor="email">
            <input className="input" id="email" name="email" type="email" required placeholder="you@example.com" />
          </Field>
          <Field label="Song Title (optional)" htmlFor="title">
            <input className="input" id="title" name="title" placeholder="My Song" />
          </Field>
          <Field label="Lyrics" htmlFor="lyrics" help="Paste your lyrics. You can also describe a theme if you don’t have full lyrics yet.">
            <textarea className="textarea h-40" id="lyrics" name="lyrics" required placeholder="Paste your lyrics here..."></textarea>
          </Field>
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Vibe / Genre" htmlFor="vibe">
              <input className="input" id="vibe" name="vibe" placeholder="Indie folk, country, worship, lo-fi, etc." />
            </Field>
            <Field label="Tempo Preference" htmlFor="bpm">
              <select className="select" id="bpm" name="bpm">
                <option value="">No preference</option>
                <option>Slow</option>
                <option>Medium</option>
                <option>Fast</option>
              </select>
            </Field>
          </div>
          <Field label="Reference Track (optional)" htmlFor="reference" help="Link to a song that captures your target vibe.">
            <input className="input" id="reference" name="reference" type="url" placeholder="https://open.spotify.com/..." />
          </Field>
          <Field label="Extras" htmlFor="extras" help="e.g., stems, instrumental, radio edit, vocal tuning, acoustic version">
            <input className="input" id="extras" name="extras" placeholder="Stems + acoustic version" />
          </Field>
          <Field label="Notes" htmlFor="notes" help="Anything else we should know.">
            <textarea className="textarea h-24" id="notes" name="notes" placeholder="Deadline, story behind it, dedication, keys to avoid, etc."></textarea>
          </Field>

          
{/* Honeypot anti-spam field */}
<input type="text" name="company" className="hidden" tabIndex={-1} autoComplete="off" />
<div className="flex items-center gap-3">

            <button className="btn-primary" type="submit" disabled={status==='submitting'}>
              {status==='submitting' ? 'Submitting…' : 'Submit Request'}
            </button>
            {status==='done' && <span className="text-green-400">Thanks! We’ll follow up by email.</span>}
            {status==='error' && <span className="text-red-400">Something went wrong. Try again.</span>}
          </div>
        </form>
      </div>
    </Layout>
  )
}
