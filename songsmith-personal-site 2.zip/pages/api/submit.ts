
import type { NextApiRequest, NextApiResponse } from 'next'

type Body = {
  name: string
  email: string
  title?: string
  lyrics: string
  vibe?: string
  bpm?: string
  reference?: string
  extras?: string
  notes?: string
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  const body = req.body as Body & { company?: string }
  // Honeypot
  if ((req.body as any)?.company) return res.status(200).json({ ok: true })

  // Basic validation
  if (!body?.name || !body?.email || !body?.lyrics) {
    return res.status(400).json({ error: 'Missing required fields' })
  }

  // Log the submission for now
  console.log('New submission:', body)

  // Optional: send email via Resend if configured
  try {
    const key = process.env.RESEND_API_KEY
    const to = process.env.NOTIFY_EMAIL
    if (key && to) {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: 'Songsmith <onboarding@resend.dev>',
          to: [to],
          subject: 'New Song Request',
          html: `<pre>${escapeHtml(JSON.stringify(body, null, 2))}</pre>`
        })
      })
      if (!r.ok) {
        const text = await r.text()
        console.warn('Resend error:', text)
      }
    }
  } catch (e) {
    console.warn('Notification error', e)
  }

  return res.status(200).json({ ok: true })
}

function escapeHtml(unsafe: string) {
  return unsafe.replace(/[&<"'>]/g, (m)=> ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  } as any)[m])
}
