# Songsmith (Personal "Lyrics Into Song" Site)

A clean, honest, no-dark-patterns site for turning lyrics into custom songs. Built with Next.js + Tailwind.

## One-Click Ship (Vercel)
1. Create a new GitHub repo and upload the folder contents.
2. Go to **vercel.com/new** → Import your repo.
3. Framework preset: **Next.js** (defaults are fine).
4. (Optional) Add environment variables:
   - `RESEND_API_KEY` — for email notifications.
   - `NOTIFY_EMAIL` — where to receive submissions.
5. Click **Deploy**. Your site is live in ~60 seconds.
6. Add your custom domain in Vercel → **Settings → Domains** (update your DNS to Vercel’s records).

## Netlify
- Push to Git → **New site from Git** → pick repo.
- Uses `netlify.toml` + Next plugin.
- Add the same env vars if you want email notifications.

## Self-Host (Docker)
```bash
docker build -t songsmith .
docker run -p 3000:3000 --env-file .env songsmith
```

## Local Dev
```bash
npm i
npm run dev
```
http://localhost:3000

## Configure Email Notifications (optional)
- Create a free account at **Resend** and get an API key.
- Set `RESEND_API_KEY` and `NOTIFY_EMAIL` in your hosting env.
- When someone submits the form, you’ll receive a JSON summary by email.

## Customizing
- **Brand**: `components/Layout.tsx` (header/footer name, contact email).
- **Colors**: `styles/globals.css` (the `--accent` variables).
- **Pricing**: `pages/pricing.tsx` array.
- **Copy**: `pages/index.tsx`, `pages/create.tsx`.

## Roadmap (nice-to-haves)
- Stripe deposit on `/pricing`
- Database + admin dashboard (Supabase/PlanetScale)
- File uploads (S3/Supabase)
- Auth-protected admin route for submissions

## License
MIT
